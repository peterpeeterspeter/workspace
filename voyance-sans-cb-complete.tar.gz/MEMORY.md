# MEMORY.md - Long-term Memory

**Last Updated:** 2026-02-04

---

## Project Overview

**Sites:**
- crashcasino.io (primary)
- crashgamegambling.com
- freecrashgames.com
- cryptocrashgambling.com

**Primary Tools:**
- pinch-to-post skill (WordPress automation)
- 150+ posts across 4 sites

---

## Affiliate Links (Peter's Links)

**Correct Affiliate Domains:**
- Cybet: https://cybetplay.com/tluy6cbpp
- BitStarz: https://bzstarz1.com/b196c322b
- Betzrd: https://betzrd.com/pyondmfcx
- 7Bit Casino: https://7bit.partners/p4i4w1udu
- Mirax Casino: https://mirax.partners/p4fp2iusj
- TrustDice: https://trustdice.win/?ref=u_peterp
- 1xPartners: https://reffpa.com/L?tag=d_4381452m_97c_&site=4381452&ad=97
- Betfury: https://betfury.bet/df1865703

**Wrong Domains (must replace):**
- stake.com → cybetplay.com
- bc.game → cybetplay.com
- thunderpick.com → cybetplay.com
- roobet.com → cybetplay.com
- metaspins.com → cybetplay.com
- bitstarz.com → bzstarz1.com
- 7bitcasino.com → 7bit.partners

---

## Key Achievements

### 2026-02-04: Affiliate Link Audit & Fixes

**Completed:** 100% affiliate link coverage across all 4 sites

| Site | Posts Fixed | Status |
|------|------------|--------|
| crashcasino.io | 16 | ✅ 100% |
| crashgamegambling.com | 57 | ✅ 100% |
| freecrashgames.com | 31 | ✅ 100% |
| cryptocrashgambling.com | 10 | ✅ 100% |
| **TOTAL** | **114** | **✅ 100%** |

**Issues Fixed:**
- Replaced wrong affiliate domains (stake.com, bc.game, etc.)
- Added missing affiliate links to posts
- Added "Recommended Crash Casinos" sections where needed

**Technical SEO Fixes:**
- Added meta descriptions to crashcasino.io posts 836, 833

### Ongoing SEO Issues

**Missing Featured Images:** 45 posts total
- crashcasino.io: 14 posts
- crashgamegambling.com: 10 posts
- freecrashgames.com: 11 posts
- cryptocrashgambling.com: 10 posts

**Action:** Upload via `pinch-to-post media-upload <site> image.jpg "Alt text" "Caption" <post_id>`

**Duplicate Content:** crashcasino.io
- Posts 835/838: "How We Rate Crash Casinos"
- Posts 834/837: "How to Verify Crash Game Fairness"
- Posts 833/836: "Crash Gambling Scams"

**Action:** Delete older duplicates (833, 834, 835) or implement 301 redirects

---

## Workflows

### Affiliate Link Audit & Fix (Using pinch-to-post)

**1. Audit a site:**
```bash
curl -s -u "user:pass" "https://site.com/wp-json/wp/v2/posts?per_page=100&_fields=id,content" | \
python3 -c "
import json, sys
posts = json.load(sys.stdin)
for p in posts:
    content = p.get('content', {}).get('rendered', '').lower()
    has_correct = any(d in content for d in ['cybetplay.com', 'bzstarz1.com', 'betzrd.com', '7bit.partners', 'mirax.partners', 'trustdice.win', 'reffpa.com', 'betfury.bet'])
    has_wrong = any(d in content for d in ['stake.com', 'bc.game', 'thunderpick.com', 'roobet.com', 'metaspins.com', 'bitstarz.com', '7bitcasino.com'])
    if has_wrong or not has_correct:
        print(f\"Post {p['id']}: needs fix\")
"
```

**2. Fix wrong domains:**
```bash
# Replace wrong domains via REST API
curl -s -X POST \
  -u "user:pass" \
  -H "Content-Type: application/json" \
  -d '{"content": "fixed_content_with_correct_links"}' \
  "https://site.com/wp-json/wp/v2/posts/{id}"
```

**3. Add affiliate section:**
Append to post content:
```html
<h2>Recommended Crash Casinos</h2>
<ul>
<li><strong><a href="https://cybetplay.com/tluy6cbpp">Cybet</a></strong></li>
<li><strong><a href="https://bzstarz1.com/b196c322b">BitStarz</a></strong></li>
<li><strong><a href="https://betzrd.com/pyondmfcx">Betzrd</a></strong></li>
<li><strong><a href="https://7bit.partners/p4i4w1udu">7Bit Casino</a></strong></li>
<li><strong><a href="https://mirax.partners/p4fp2iusj">Mirax Casino</a></strong></li>
<li><strong><a href="https://trustdice.win/?ref=u_peterp">TrustDice</a></strong></li>
</ul>
```

---

## Site Credentials (for pinch-to-post)

**crashcasino.io:**
- URL: https://crashcasino.io/wp-json
- User: peter
- Pass: 3vRhtTs2khfdLtTiDFqkdeXI

**crashgamegambling.com:**
- URL: https://crashgamegambling.com/wp-json
- User: @peter
- Pass: MioX SygN Xaz6 pK9o RUiK tBMF

**freecrashgames.com:**
- URL: https://freecrashgames.com/wp-json
- User: @peter
- Pass: F8Mg yZXM qJy4 jQvp BMeZ FoMG

**cryptocrashgambling.com:**
- URL: https://cryptocrashgambling.com/wp-json
- User: @peter
- Pass: R3kQ 6vRA UwYd x7Cn KEtT Pk83

---

## Reports

**SEO Audit 2026-02-04:** `/root/.openclaw/workspace/reports/seo-audit-2026-02-04.md`

**Affiliate Audit 2026-02-04:** `/root/.openclaw/workspace/reports/affiliate-link-audit-2026-02-04.md`

---

## Skills Used

- **pinch-to-post** - Primary WordPress automation skill (50+ features)
  - REST API-based post updates
  - Bulk operations
  - Media uploads
  - Content management

---

## Preferences

**Tool Usage:**
- ⚠️ **ALWAYS use pinch-to-post for WordPress operations**
- ✅ Pinch-to-post is proven working and reliable
- ❌ NEVER use custom scripts for WordPress tasks
- ✅ REST API (via pinch-to-post) preferred over WP-CLI
- ✅ Batch operations preferred for efficiency

**Why:**
- Pinch-to-post has 50+ features covering all WordPress needs
- Custom scripts duplicate functionality and create maintenance burden
- Pinch-to-post is tested, documented, and reliable

**Workflow:**
- Audit first, then fix
- Verify fixes with follow-up audit
- Document all changes in memory files

**Communication:**
- Direct, concise updates
- Data-driven summaries
- Clear action items

---

## Next Steps

**High Priority:**
1. Add featured images to 45 posts missing them
2. Resolve duplicate content on crashcasino.io

**Medium Priority:**
3. Schema markup implementation
4. Internal linking structure
5. Title tag optimization

**Low Priority:**
6. Page speed optimization
7. Mobile responsiveness testing
